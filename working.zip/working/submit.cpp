//////////// LIBRARY.h /////////////////////
#include<bits/stdc++.h>
#include<unistd.h>
#include<stdio.h> 
#include<stdlib.h> 
#include<unistd.h> 
#include<sys/types.h> 
#include<string.h> 
#include<sys/wait.h> 
#include<sys/shm.h>
#include <stdio.h> 
#include <sys/ipc.h> 
#include <sys/msg.h> 
#include<sys/time.h>
#include<signal.h>
#include<sys/ipc.h>
#include<stdlib.h>
#define MAX 100
#define REQUEST_MADE 1
#define REQUEST_FULLFIL 2
#define NO_REQUEST 0

typedef struct _MESSAGE_BUFFER{
    long message_type;
    char text[MAX];
} MESSAGE_BUFFER;
// for a page_table T, and process i, T[i].frame[j] gives the frame_no for the page_no j and T[i].valid[j] gives whether it is
// valid or not
typedef struct _PAGE_TABLE{
	int *valid;
	int *page_no;
	int *frame_no;	
    int *timestamp;
} PAGE_TABLE;

typedef struct _process_node{
	int pid;
	struct _process_node *next;
}process_node;

typedef struct _process_mem_access{
	int valid;
	int page_no;
	int frame_no;
}process_mem_access;

typedef struct{
	int *page_no;
	int *frame_no;
}TLB;
// Timestamp is required to perform LRU page replacement algorithm
typedef struct _FREE_FRAME{
	int isfree;
} FREE_FRAME;

////////////////////// MASTER.CPP //////////////////////////////
#include "Library.h"
using namespace std;

char *str[MAX],command[MAX];
int k,m,f,s;
PAGE_TABLE *page_table;
FREE_FRAME *free_frame_list;

MESSAGE_BUFFER MQ;

void init_str(){
    for(int i=0;i<6;i++)
        str[i]=new char[1000];
}

string Generate_Page_Ref_String(int no_of_pages,int page_ref_str_len){
    string ans="";
    default_random_engine  generator;
    double mu_page_ref=no_of_pages/2.0,sigma_page_ref=1.0;
    for(int i=0;i<page_ref_str_len;i++){
        normal_distribution<double> distribution(mu_page_ref,sigma_page_ref);
        double val=distribution(generator);
        if(int(val)>=no_of_pages){
            val = (int)no_of_pages-1;
        }
        if(int(val)<0){
            val = 0;
        }
        ans.append(to_string((int)val)+((i==page_ref_str_len-1)?"":","));
        mu_page_ref=val;
    }
    return ans;
}

int create_shared_page_table(){
    key_t  key=ftok("SM1",65); 
    int shmid=shmget(key,sizeof(PAGE_TABLE[MAX]),0666|IPC_CREAT);
    
    if(shmid<0){
        printf("Creation of shared page table file error!!\n");
        return -1;
    }
    
    page_table=(PAGE_TABLE*)shmat(shmid,NULL,0);
    for(int i=0;i<k;i++){
        page_table[i].valid=new int[m+1];
        page_table[i].frame_no=new int[m+1];
        page_table[i].timestamp=new int[m+1];
        page_table[i].page_no=new int[m+1];
    }
    memset(page_table,-1,sizeof page_table);
    return shmid; 
}
int create_free_frame_list(){
    key_t  key=ftok("SM2",65); 
    int shmid=shmget(key,MAX*sizeof(FREE_FRAME),0666|IPC_CREAT);
    if(shmid<0){
        printf("Creation of shared free frame list file error!!\n");
        return -1;
    }
    free_frame_list=(FREE_FRAME*)shmat(shmid,NULL,0);
    for(int i=0;i<MAX;i++){
        free_frame_list[i].isfree=0;
    }
    
    return shmid; 
}
int create_ready_queue_MQ1(){
    key_t key;int msgid; 
    key = ftok("MQ1", 65); 
    msgid = msgget(key, 0666 | IPC_CREAT); 
    return msgid;
    //printf("Write Data : "); 
    //gets(message.mesg_text); 
  
    // msgsnd to send message 
    //msgsnd(msgid, &message, sizeof(message), 0); 
}
int create_Scheduler_MMU_MQ2(){
    key_t key;int msgid; 
    key = ftok("MQ2", 65); 
    msgid = msgget(key, 0666 | IPC_CREAT); 
    return msgid;
}
int create_Process_MMU_MQ3(){
    key_t key;int msgid; 
    key = ftok("MQ3", 65); 
    msgid = msgget(key, 0666 | IPC_CREAT); 
    return msgid;
}
int create_notification_Scheduler_Master(){
    key_t key;int msgid; 
    key = ftok("notification_sched_master", 65); 
    msgid = msgget(key, 0666 | IPC_CREAT); 
    return msgid;
}

int mmu_pid, scheduler_pid, p_pid[100], no_pr;
void shut_off(int id){
    kill(mmu_pid, SIGTERM);
    kill(scheduler_pid, SIGTERM);
    for(int i=0;i<no_pr;i++)
        kill(p_pid[i], SIGTERM);
    cout<<"TERMINATED ALL THE CHILD PROCESSES. EXITING.."<<endl;
    exit(0);
}

int main(){
    cout<<"[Master: "<<getpid()<<" ]"<<endl;
    // Taking inputs to the program
    cout<<"Enter the value of k:\n";
    cin>>k;
    cout<<"Enter the value of m:\n";
    cin>>m;
    cout<<"Enter the value of f:\n";
    cin>>f;

    int master_pid = getpid();
    signal(SIGUSR1, shut_off);
    /* Data Structures Initialization */
    // Creation of message queues
    int ID_MQ1=create_ready_queue_MQ1(),ID_MQ2=create_Scheduler_MMU_MQ2(),ID_MQ3=create_Process_MMU_MQ3();
    // Creaton of shared memories
    int ID_SM1=create_shared_page_table(),ID_SM2=create_free_frame_list();
    int ID_notif=create_notification_Scheduler_Master();
    cout<<"Data Structures Initialized\n";
    cout<<"(Master) -q "<<ID_SM1<<" -q "<<ID_SM2<<" -q "<<ID_MQ1<<" -q "<<ID_MQ2<<" -q "<<ID_MQ3<<endl;
    int pid_MMU;
    // Run the MMU process
    if(fork()==0){    
        init_str();
        strcpy(str[0],"g++");
        strcpy(str[1],"--std=c++14");
        strcpy(str[2],"-oMMU");
        strcpy(str[3],"MMU.cpp");
        str[4]=NULL;  
        strcpy(command,"g++");
        execvp(command,str);
        cout<<"Excevp failed to compile MMU!!\n";
        return 0;
    }
    else{
        wait(NULL);
        if((pid_MMU=fork())==0){
            init_str();
            strcpy(command,"./MMU");
            strcpy(str[0],"MQ2");
            strcpy(str[1],"MQ3");
            strcpy(str[2],"SM1");
            strcpy(str[3],"SM2");
            str[4]=NULL;
            execvp(command,str);
            cout<<"Excevp failed to execute MMU!!\n";
            return 0;
        }
        mmu_pid = pid_MMU;
    }
    cout<<"MMU running\n";
    


    // Create k Processes 
    for(int i=0;i<k;i++){
         int pid_child,pc;
        if((pc=fork())==0){  
            init_str();  
            strcpy(str[0],"g++");
            strcpy(str[1],"--std=c++14");
            strcpy(str[2],("-oProcess"+to_string(i)).c_str());
            strcpy(str[3],"Process.cpp");
            str[4]=NULL;  
            strcpy(command,"g++");
            execvp(command,str);
            cout<<"Excevp failed to compile Process:"<<i<<"\n";
            return 0;
        }
        // Waiting for compilation to get over
        int status=0;
        waitpid(pc,&status,0);
        sleep(1);
        if((pid_child=fork())==0){
            init_str();
            int mm=rand()%m+1,pp=rand()%(8*m)+2*m;
            strcpy(command,("./Process"+to_string(i)).c_str());
            // Instead of i, sending the pid_child is a good idea
            strcpy(str[0],to_string(i).c_str());
            strcpy(str[1],"MQ1");
            strcpy(str[2],"MQ3");
            strcpy(str[3],Generate_Page_Ref_String(mm,pp).c_str());
            str[4]=NULL;
            execvp(command,str);
            printf("Error is %s\n",strerror(errno));
            cout<<"Excevp failed to run Process:"<<i<<"\n";
            return 0;
        }
        p_pid[i] = pid_child;
       // sleep(0.1);
        // Putting the process to sleep as soon as it is put into ready queue
        // so that for scheduler to schedule it, it can wake it up again
        //kill(pid_child,SIGUSR1);


        // Adding the process ID in the ready in FCFS fashion
        //char process_id[MAX];
        // Sleep for 0.25 then again continue to generate new processes

    }
        // Run the Scheduler
    int pid_scheduler;
    if(fork()==0){    
        init_str();
        strcpy(str[0],"g++");
        strcpy(str[1],"--std=c++14");
        strcpy(str[2],"-oscheduler");
        strcpy(str[3],"Scheduler.cpp");
        str[4]=NULL;  
        strcpy(command,"g++");
        execvp(command,str);
        cout<<"Excevp failed to compile Scheduler!!\n";
        return 0;
    }
    else{
        wait(NULL);
        if((pid_scheduler=fork())==0){
            init_str();
            strcpy(command,"./scheduler");
            strcpy(str[0],"MQ1");
            strcpy(str[1],"MQ2");
            strcpy(str[2],to_string(k).c_str());
            strcpy(str[3],to_string(master_pid).c_str());
            str[4] = NULL;
            execvp(command,str);
            cout<<"Excevp failed to execute Scheduler!!\n";
            return 0;
        }
        scheduler_pid = pid_scheduler;
    }
    cout<<"Scheduler Running\n";
    pause();


    //while(1);
   // kill(pid_scheduler,SIGINT);
    //kill(pid_MMU,SIGINT);

    return 0;
}

///////////// MMU.CPP /////////////////////
#include "Library.h"
using namespace std;
MESSAGE_BUFFER message;
int process_id;
TLB tlb[MAX];
PAGE_TABLE *page_table;
FREE_FRAME *free_frame_list;
int timestamp_id,tmp;
// tlb [i] is the tlb for each process i
void init(){
    for(int i=0;i<MAX;i++){
        tlb[i].page_no=new int[MAX];
        tlb[i].frame_no=new int[MAX];
        for(int j=0;j<MAX;j++){
            tlb[i].frame_no[j]=tlb[i].page_no[j]=-1;
        }
        //memset(tlb[i].page_no,-1,sizeof tlb[i].page_no);
        //memset(tlb[i].frame_no,-1,sizeof tlb[i].frame_no);
    }
}
void update_tlb(int page_no,int frame_no){
    for(int i=0;i<MAX;i++){
        if(tlb[process_id].page_no[i]==page_no){
            tlb[process_id].page_no[i]=page_no;
            tlb[process_id].frame_no[i]=frame_no;
            return;
        }
    }
    tlb[process_id].page_no[0]=page_no;
    tlb[process_id].frame_no[0]=frame_no;
}
int search_TLB(int page_no){
    for(int i=0;i<MAX;i++){
        if(tlb[process_id].page_no[i]==page_no && tlb[process_id].frame_no[i]!=-1){
            return tlb[process_id].frame_no[i];
        }
    }
    
    return -1;
}
int create_shared_page_table(){
    key_t  key=ftok("SM1",65); 
    int shmid=shmget(key,sizeof(PAGE_TABLE[MAX]),0666|IPC_CREAT);
    
    if(shmid<0){
        printf("Creation of shared page table file error!!\n");
        return -1;
    } 
    page_table=(PAGE_TABLE*)shmat(shmid,NULL,0);
    for(int i=0;i<MAX;i++){
        page_table[i].valid=new int[MAX];
        page_table[i].frame_no=new int[MAX];
        page_table[i].timestamp=new int[MAX];
        page_table[i].page_no=new int[MAX];
        for(int j=0;j<MAX;j++){
            page_table[i].valid[j]=-1;
            page_table[i].frame_no[j]=-1;
            page_table[i].timestamp[j]=-1;
            page_table[i].page_no[j]=-1;
        }
    }

    
    return shmid; 
}
int create_free_frame_list(){
    key_t  key=ftok("SM2",65); 
    int shmid=shmget(key,MAX*sizeof(FREE_FRAME),0666|IPC_CREAT);
    if(shmid<0){
        printf("Creation of shared free frame list file error!!\n");
        return -1;
    }
    free_frame_list=(FREE_FRAME*)shmat(shmid,NULL,0);
    for(int i=0;i<MAX;i++){
        free_frame_list[i].isfree=1;
    }
    return shmid; 
}
int attach_process_mmu_msg_queue(char *MQ3){
    key_t  key=ftok("MQ3",65); int msgid;
    msgid = msgget(key,IPC_CREAT|0666); 
    return msgid;
}
int attach_mmu_scheduler_msg_queue(char *MQ2){
    key_t  key=ftok("MQ2",65); int msgid;
    msgid = msgget(key,IPC_CREAT|0666); 
    return msgid;
}
int main(int argc,char **argv){

    cout<<"[MMU: "<<getpid()<<" ]"<<endl;
    char *MQ2=argv[0];
    char *MQ3=argv[1];
    char *SM1=argv[2];
    char *SM2=argv[3];
    init();
    int ID_MQ3=attach_process_mmu_msg_queue(MQ3),ID_MQ2=attach_mmu_scheduler_msg_queue(MQ2);

    int page_id=create_shared_page_table();
    int frame_id=create_free_frame_list();

    
    while(1){

        msgrcv(ID_MQ3,&message,sizeof(message),6,0);
        try{
            process_id=stoi((string(message.text)),NULL,10);
        }
        catch(int x){
            process_id=0;
            continue;
        }
        msgrcv(ID_MQ3,&message,sizeof(message),1,0);
        if(strcmp(message.text,"-9")==0){

            strcpy(message.text,"TERMINATED");
            message.message_type=10;
            msgsnd(ID_MQ2,&message,sizeof(message),0);   

            continue;
        }

        int page_no=0;
        try{
            page_no=stoi((string(message.text)),NULL,10);
        }
        catch(int x){
            page_no=0;
            continue;
        }
        int frame_no=search_TLB(page_no);
        cout<<"(MMU) Process-"<<process_id<<" demanding for page "<<page_no<<" after tlb search, frame_no = "<<frame_no<<endl;

        if(frame_no!=-1){

            strcpy(message.text,to_string(frame_no).c_str());
            message.message_type=2;
            msgsnd(ID_MQ3,&message,sizeof(message),0);
            cout<<"Process_ID:"<<process_id<<" Page_No:"<<page_no<<" Frame_No:"<<frame_no<<" Timestamp:"<<(++tmp)<<endl;
        }
        else{

            int flag=0;
            for(int i=0;i<MAX;i++){

                if(page_table[process_id].page_no[i]==page_no && page_table[process_id].frame_no[i]!=-1){
                    frame_no=page_table[process_id].frame_no[i];
                    strcpy(message.text,to_string(frame_no).c_str());
                    message.message_type=2;
                    msgsnd(ID_MQ3,&message,sizeof(message),0);
                    flag=1;
                    update_tlb(page_no,frame_no);
                    break;
                }
            }
            if(!flag){

                strcpy(message.text,"-1");
                message.message_type=2;
                msgsnd(ID_MQ3,&message,sizeof(message),0);

                int free_frame=-1;
                for(int i=0;i<MAX;i++){
                    if(free_frame_list[i].isfree!=-1){
                        free_frame=i;
                        free_frame_list[i].isfree=-1;
                        break;
                    }
                }

                if(free_frame!=-1){
                    int flag3=0,flag4=0;
                    for(int i=0;i<MAX;i++){
                        if(tlb[process_id].frame_no[i]==-1 && tlb[process_id].page_no[i]==-1){
                            tlb[process_id].frame_no[i]=free_frame;
                            tlb[process_id].page_no[i]=page_no;
                            flag3=1;
                            break;
                        }
                    }
                    if(!flag3){
                        tlb[process_id].frame_no[0]=free_frame;
                        tlb[process_id].page_no[0]=page_no;
                    }

                    for(int i=0;i<MAX;i++){
                        if(page_table[process_id].page_no[i]==-1 && page_table[process_id].frame_no[i]==-1){
                            page_table[process_id].frame_no[i]=free_frame;
                            page_table[process_id].page_no[i]=page_no;
                            page_table[process_id].timestamp[i]=(++timestamp_id);
                            flag4=1;
                            break;
                        }
                    }
                    if(!flag4){
                        page_table[process_id].frame_no[0]=free_frame;
                        page_table[process_id].page_no[0]=page_no;
                        page_table[process_id].timestamp[0]=(++timestamp_id);
                    }

                }
                else{
                    int LRU_idx=0,timestamp=1e9+7,replaced_frame=-2;
                    for(int i=0;i<MAX;i++){
                        if(page_table[process_id].timestamp[i]<=timestamp){
                            LRU_idx=i;
                            timestamp=page_table[process_id].timestamp[i];
                            replaced_frame=page_table[process_id].frame_no[i];
                        }
                    }
                    page_table[process_id].page_no[LRU_idx]=page_no;
                    page_table[process_id].frame_no[LRU_idx]=replaced_frame;
                    
                    for(int i=0;i<MAX;i++){
                        if(tlb[process_id].page_no[i]==page_no){
                            tlb[process_id].frame_no[i]=replaced_frame;
                            break;
                        }
                    }

                }
                strcpy(message.text,"PAGE_FAULT_HANDLED");
                message.message_type=10;
                msgsnd(ID_MQ2,&message,sizeof(message),0);

            }

        }
   }

    return 0;
}

////////////// SCHEDULER.CPP /////////////////
#include "Library.h"
using namespace std;
#define PAGE 1
#define FRAME 0

// key_t key;
// int shmBuf1id;
// int *buf1Ptr;

MESSAGE_BUFFER MQ;
key_t key;
int msgid;
int create_ready_queue_MQ1(char *MQ1){
    key=ftok(MQ1,65);
    msgid=msgget(key,0666|IPC_CREAT);
    return msgid;
}

int create_message_queue_MQ2(char *MQ2){
    key=ftok(MQ2,65);
    msgid=msgget(key,0666|IPC_CREAT);
    return msgid;
}


int main(int argc,char *argv[]){
    cout<<"[Scheduler: "<<getpid()<<" ]"<<endl;
   //freopen ("Scheduler_out.txt", "w", stdout);
    //printf("here\n");
    char *MQ1=argv[0];
    char *MQ2=argv[1];
    int ID_MQ1=create_ready_queue_MQ1(MQ1);
    int ID_MQ2=create_message_queue_MQ2(MQ2);
    // cout<<"[Scheduler "<<getpid()<<"]"<<": ID_MQ2 is:"<<ID_MQ2<<endl;
    // cout<<"(Scheduler) ID_MQ1: "<<ID_MQ1<<", ID_MQ2: "<<ID_MQ2<<endl;

    // sleep(5);
    int no_terminated = 0, k = atoi(argv[2]), master_pid = atoi(argv[3]);
    while(no_terminated<k){

        // Scheduling operation to be done,waiting on the ready queue
        cout<<"[Scheduler "<<getpid()<<"] "<<"waiting for ready queue\n";
        msgrcv(ID_MQ1,&MQ,sizeof(MQ),401,0);  
        cout<<"(Scheduler) Got from ID_MQ1 type 401 "<<string(MQ.text)<<endl;
        int pid_process;
        try{
            //cout<<"DEBUG:"<<stoi(string(MQ.text),NULL,10)<<endl;
            pid_process=stoi(string(MQ.text),NULL,10);
        }
        catch(int c){
            pid_process=0;
            continue;
        }
        if(pid_process==-1)break;
        //printf("The Process to be scheduled is :%d\n",pid_process);
        
        // Signalling the process to start
        // cout<<"[Scheduler "<<getpid()<<"] "<<" waking up "<<pid_process<<endl;
        kill(pid_process,SIGUSR1);
        
        // Keeping the MMU queue watch
        msgrcv(ID_MQ2,&MQ,sizeof(MQ),10,0);
        cout<<"(Scheduler) Got from ID_MQ2 type 10 "<<string(MQ.text)<<endl;
        // After the first page fault the message goes to sleep, so we have to wake it up again
        
        if(strcmp(MQ.text,"PAGE_FAULT_HANDLED")==0){
            cout<<"(Scheduler) PAGE_FAULT_HANDLED "<<endl;
            // Page fault handled so should again queue the process again,so adding again to message queue
            // kill(pid_process,SIGUSR2);
            strcpy(MQ.text,to_string(pid_process).c_str());
            MQ.message_type=401;
            msgsnd(ID_MQ1,&MQ,sizeof(MQ),0);
        }
        else if(strcmp(MQ.text,"TERMINATED")==0) 
            no_terminated++;
        else {
            cout<<"(Scheduler) UNEXPECTED MESSAGE: "<<MQ.text<<endl;
        }
        //cout<<string(MQ.text)<<endl;   
        // If terminated is received then no need of doing all of this, just schedule next process

    }
    cout<<"(Scheduler) All Process Terminated\n";
    kill(master_pid, SIGUSR1);
    pause();
    // printf("Scheduler called!\n");
    // printf("The data entered is :");
    return 0;
}

///////////// PROCESS.cpp ///////////////
#include "Library.h"
#include<errno.h>
using namespace std;
char *MQ1,*MQ3,*SM1,*SM2;
MESSAGE_BUFFER message;
void run(int id){
    //cout<<"In run signal handler\n";
    signal(SIGUSR1,run);
    return;
}
void pause(int id){
	pause();
    signal(SIGUSR2,pause);
}

int page_ref_no[MAX];
int acces_no,total_no;
process_mem_access* Process_mem_access;


int attach_process_mmu_shared_mem(char* MQ3){
    key_t  key=ftok("MQ3",65);int msgid; 
    msgid = msgget(key, IPC_CREAT|0666); 
    return msgid;
}
int attach_MQ1(){
    key_t  key=ftok("MQ1",65);int msgid; 
    msgid = msgget(key, IPC_CREAT|0666); 
    return msgid;
}
int main(int argv,char **argc){

    cout<<"\t[Process: "<<getpid()<<" ]"<<endl;
    signal(SIGUSR1,run);
    signal(SIGUSR2,pause);
    char *MQ1=argc[1];
    char *MQ3=argc[2];
    string page_ref_str(argc[3]);

    int ID_MQ3=attach_process_mmu_shared_mem(MQ3);

    int ID_MQ1=attach_MQ1();
    MESSAGE_BUFFER MQ;
    strcpy(MQ.text,to_string(getpid()).c_str());
    MQ.message_type=401;
    // cout<<"\t[Process: "<<getpid()<<" ]"<<"sending ID_MQ1 type 4, text: "<<MQ.text<<endl;
    msgsnd(ID_MQ1,&MQ,sizeof(MQ),0);
    // cout<<"\t[Process: "<<getpid()<<" ]"<<", ID_MQ3: "<<ID_MQ3<<endl;

    // cout<<"\t[Process "<<getpid()<<"] "<<" going to sleep\n";
    pause();
    // cout<<"\t[Process "<<getpid()<<"] "<<" woke up\n";
    int process_id=0;
    try{
        process_id=stoi(string(argc[0]),NULL,10);
    }
    catch(int x){
        process_id=0;
    }

 

    for(int i=0;i<page_ref_str.length();){
        int j=i;
        while(j<page_ref_str.length() && page_ref_str[j]!=',')j++;
        int page_val;
        try{
            page_val=stoi(page_ref_str.substr(i,j-i),NULL,10);
        }
        catch(int x){
            page_val=0;
            continue;
        }
        page_ref_no[i]=page_val;
        cout<<"\t[Process "<<getpid()<<"]"<<"Requested:"<<page_val<<endl;
        message.message_type=6;
        strcpy(message.text,to_string(process_id).c_str());
        msgsnd(ID_MQ3,&message,sizeof(message),0);
        

        message.message_type=1;
        strcpy(message.text,page_ref_str.substr(i,j-i).c_str());
        msgsnd(ID_MQ3,&message,sizeof(message),0);
    
        MESSAGE_BUFFER receive;
        msgrcv(ID_MQ3,&receive,sizeof(receive),2,0);
        int frame_no = atoi(receive.text);
        cout<<"\t[Process "<<getpid()<<"]"<<" frame_no: "<<frame_no<<endl;
        if(frame_no==-1){
            cout<<"\t[Process "<<getpid()<<"]"<<" Page Fault occured retrying again\n";
            pause();
            continue;
        }
        else if(frame_no<=-2){
            message.message_type=1;
            strcpy(message.text,"-9");
            int r=msgsnd(ID_MQ3,&message,sizeof(message),0);
            
            return 0;
        }
        cout<<"\t[Process "<<getpid()<<"]"<<" Received frame_no:"<<frame_no<<" for page_no:"<<page_val<<endl;
        i=j+1;
    }   

    message.message_type=6;
    strcpy(message.text,to_string(process_id).c_str());
    int r=msgsnd(ID_MQ3,&message,sizeof(message),0);
    
    message.message_type=1;
    strcpy(message.text,"-9");
    r=msgsnd(ID_MQ3,&message,sizeof(message),0);
    
    return 0;
}