#include "Library.h"
#include<errno.h>
using namespace std;
char *MQ1,*MQ3,*SM1,*SM2;
MESSAGE_BUFFER message;
void run(int id){
    //cout<<"In run signal handler\n";
    signal(SIGUSR1,run);
    return;
}
void pause(int id){
	pause();
    signal(SIGUSR2,pause);
}

int page_ref_no[MAX];
int acces_no,total_no;
process_mem_access* Process_mem_access;


int attach_process_mmu_shared_mem(char* MQ3){
    key_t  key=ftok("MQ3",65);int msgid; 
    msgid = msgget(key, IPC_CREAT|0666); 
    return msgid;
}
int attach_MQ1(){
    key_t  key=ftok("MQ1",65);int msgid; 
    msgid = msgget(key, IPC_CREAT|0666); 
    return msgid;
}
int main(int argv,char **argc){

    cout<<"\t[Process: "<<getpid()<<" ]"<<endl;
    signal(SIGUSR1,run);
    signal(SIGUSR2,pause);
    char *MQ1=argc[1];
    char *MQ3=argc[2];
    string page_ref_str(argc[3]);

    int ID_MQ3=attach_process_mmu_shared_mem(MQ3);

    int ID_MQ1=attach_MQ1();
    MESSAGE_BUFFER MQ;
    strcpy(MQ.text,to_string(getpid()).c_str());
    MQ.message_type=401;
    // cout<<"\t[Process: "<<getpid()<<" ]"<<"sending ID_MQ1 type 4, text: "<<MQ.text<<endl;
    msgsnd(ID_MQ1,&MQ,sizeof(MQ),0);
    // cout<<"\t[Process: "<<getpid()<<" ]"<<", ID_MQ3: "<<ID_MQ3<<endl;

    // cout<<"\t[Process "<<getpid()<<"] "<<" going to sleep\n";
    pause();
    // cout<<"\t[Process "<<getpid()<<"] "<<" woke up\n";
    int process_id=0;
    try{
        process_id=stoi(string(argc[0]),NULL,10);
    }
    catch(int x){
        process_id=0;
    }

 

    for(int i=0;i<page_ref_str.length();){
        int j=i;
        while(j<page_ref_str.length() && page_ref_str[j]!=',')j++;
        int page_val;
        try{
            page_val=stoi(page_ref_str.substr(i,j-i),NULL,10);
        }
        catch(int x){
            page_val=0;
            continue;
        }
        page_ref_no[i]=page_val;
        cout<<"\t[Process "<<getpid()<<"]"<<"Requested:"<<page_val<<endl;
        message.message_type=6;
        strcpy(message.text,to_string(process_id).c_str());
        msgsnd(ID_MQ3,&message,sizeof(message),0);
        

        message.message_type=1;
        strcpy(message.text,page_ref_str.substr(i,j-i).c_str());
        msgsnd(ID_MQ3,&message,sizeof(message),0);
    
        MESSAGE_BUFFER receive;
        msgrcv(ID_MQ3,&receive,sizeof(receive),2,0);
        int frame_no = atoi(receive.text);
        cout<<"\t[Process "<<getpid()<<"]"<<" frame_no: "<<frame_no<<endl;
        if(frame_no==-1){
            cout<<"\t[Process "<<getpid()<<"]"<<" Page Fault occured retrying again\n";
            pause();
            continue;
        }
        else if(frame_no<=-2){
            message.message_type=1;
            strcpy(message.text,"-9");
            int r=msgsnd(ID_MQ3,&message,sizeof(message),0);
            
            return 0;
        }
        cout<<"\t[Process "<<getpid()<<"]"<<" Received frame_no:"<<frame_no<<" for page_no:"<<page_val<<endl;
        i=j+1;
    }   

    message.message_type=6;
    strcpy(message.text,to_string(process_id).c_str());
    int r=msgsnd(ID_MQ3,&message,sizeof(message),0);
    
    message.message_type=1;
    strcpy(message.text,"-9");
    r=msgsnd(ID_MQ3,&message,sizeof(message),0);
    
    return 0;
}