#include "Library.h"
using namespace std;
#define PAGE 1
#define FRAME 0

// key_t key;
// int shmBuf1id;
// int *buf1Ptr;

MESSAGE_BUFFER MQ;
key_t key;
int msgid;
int create_ready_queue_MQ1(char *MQ1){
    key=ftok(MQ1,65);
    msgid=msgget(key,0666|IPC_CREAT);
    return msgid;
}

int create_message_queue_MQ2(char *MQ2){
    key=ftok(MQ2,65);
    msgid=msgget(key,0666|IPC_CREAT);
    return msgid;
}


int main(int argc,char *argv[]){
    cout<<"[Scheduler: "<<getpid()<<" ]"<<endl;
   //freopen ("Scheduler_out.txt", "w", stdout);
    //printf("here\n");
    char *MQ1=argv[0];
    char *MQ2=argv[1];
    int ID_MQ1=create_ready_queue_MQ1(MQ1);
    int ID_MQ2=create_message_queue_MQ2(MQ2);
    // cout<<"[Scheduler "<<getpid()<<"]"<<": ID_MQ2 is:"<<ID_MQ2<<endl;
    // cout<<"(Scheduler) ID_MQ1: "<<ID_MQ1<<", ID_MQ2: "<<ID_MQ2<<endl;

    // sleep(5);
    int no_terminated = 0, k = atoi(argv[2]), master_pid = atoi(argv[3]);
    while(no_terminated<k){

        // Scheduling operation to be done,waiting on the ready queue
        cout<<"[Scheduler "<<getpid()<<"] "<<"waiting for ready queue\n";
        msgrcv(ID_MQ1,&MQ,sizeof(MQ),401,0);  
        cout<<"(Scheduler) Got from ID_MQ1 type 401 "<<string(MQ.text)<<endl;
        int pid_process;
        try{
            //cout<<"DEBUG:"<<stoi(string(MQ.text),NULL,10)<<endl;
            pid_process=stoi(string(MQ.text),NULL,10);
        }
        catch(int c){
            pid_process=0;
            continue;
        }
        if(pid_process==-1)break;
        //printf("The Process to be scheduled is :%d\n",pid_process);
        
        // Signalling the process to start
        // cout<<"[Scheduler "<<getpid()<<"] "<<" waking up "<<pid_process<<endl;
        kill(pid_process,SIGUSR1);
        
        // Keeping the MMU queue watch
        msgrcv(ID_MQ2,&MQ,sizeof(MQ),10,0);
        cout<<"(Scheduler) Got from ID_MQ2 type 10 "<<string(MQ.text)<<endl;
        // After the first page fault the message goes to sleep, so we have to wake it up again
        
        if(strcmp(MQ.text,"PAGE_FAULT_HANDLED")==0){
            cout<<"(Scheduler) PAGE_FAULT_HANDLED "<<endl;
            // Page fault handled so should again queue the process again,so adding again to message queue
            // kill(pid_process,SIGUSR2);
            strcpy(MQ.text,to_string(pid_process).c_str());
            MQ.message_type=401;
            msgsnd(ID_MQ1,&MQ,sizeof(MQ),0);
        }
        else if(strcmp(MQ.text,"TERMINATED")==0) 
            no_terminated++;
        else {
            cout<<"(Scheduler) UNEXPECTED MESSAGE: "<<MQ.text<<endl;
        }
        //cout<<string(MQ.text)<<endl;   
        // If terminated is received then no need of doing all of this, just schedule next process

    }
    cout<<"(Scheduler) All Process Terminated\n";
    kill(master_pid, SIGUSR1);
    pause();
    // printf("Scheduler called!\n");
    // printf("The data entered is :");
    return 0;
}